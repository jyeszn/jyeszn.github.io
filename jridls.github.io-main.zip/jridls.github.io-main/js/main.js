import './accordion.js';
import './translation.js';